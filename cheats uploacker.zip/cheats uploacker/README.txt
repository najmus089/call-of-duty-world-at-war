.::CREATED BY DEBARSHI::.

HOW TO USE:
1.backup the old binkw32.dll
2.copy the contents of the downloaded zip file and paste/overwrite into the cod5 installation directory
3.run the game and press F2 to unlock and F3 to lock console cheats
This is only for version 1.7 of cod5
The host have to use it to create console cheats enebled co-op server.

enjoy :)

For ay prob about this cheat just send me an email to debarshibiswas35@gmail.com